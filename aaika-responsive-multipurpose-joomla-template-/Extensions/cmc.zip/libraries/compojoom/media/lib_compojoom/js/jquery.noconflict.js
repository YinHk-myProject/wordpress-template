/*
 * https://compojoom.com
 * Copyright (c) 2013 - 2014 Yves Hoppe; License: GPL v2 or later
 */

jQuery.noConflict();