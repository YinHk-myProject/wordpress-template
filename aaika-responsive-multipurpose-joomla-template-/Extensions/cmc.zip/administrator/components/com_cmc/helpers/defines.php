<?php
/**
 * @package    MatukioEvents
 * @author     Yves Hoppe <yves@compojoom.com>
 * @date       2016-02-12
 *
 * @copyright  Copyright (C) 2008 - 2016 compojoom.com - Yves Hoppe. All rights reserved
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

defined('_JEXEC') or die ('Restricted access');

define("CMC_VERSION", '3.0.1');
define("CMC_DATE", "2016-09-02");
define("CMC_YEAR", "2016");
