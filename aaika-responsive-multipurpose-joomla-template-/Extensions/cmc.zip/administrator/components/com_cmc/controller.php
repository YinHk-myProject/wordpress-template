<?php
/**
 * @package    CMC
 * @author     Compojoom <contact-us@compojoom.com>
 * @date       2016-04-15
 *
 * @copyright  Copyright (C) 2008 - 2016 compojoom.com - Daniel Dimitrov, Yves Hoppe. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

jimport('joomla.application.component.controller');

defined('_JEXEC') or die ('Restricted access');

/**
 * Class CmcController
 *
 * @since  1.0
 */
class CmcController extends JControllerLegacy
{
	protected $default_view = 'cpanel';
}
