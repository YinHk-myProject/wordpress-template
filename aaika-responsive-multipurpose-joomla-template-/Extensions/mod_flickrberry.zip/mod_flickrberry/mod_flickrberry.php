<?php
/**
 * @package     atomix
 * @subpackage  mod_atom_facebook_likebox
 * @author - Thomas Andrew Erickson
 * @copyright - Copyright (C) 2012 - 2014 Atomix Studios, Inc. All rights reserved.
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * Websites: www.atomixstudios.com
 * Technical Support:  www.atomixstudios.com/support.html
*/
// no direct access
defined( '_JEXEC' ) or die('Restricted Access');
require JModuleHelper::getLayoutPath('mod_flickrberry', $params->get('layout'));