<?php
/*
* @package Sematic
* @copyright (C) 2018 by Joomlastars - All rights reserved!
* @license GNU General Public License, version 2 (http://www.gnu.org/licenses/gpl-2.0.html)
* @author Joomlastars <author@joomlastars.co.in>
* @authorurl <http://themeforest.net/user/joomlastars>
*/
?>
<?php ini_set("display_errors","0");
$app = JFactory::getApplication();
$itemid = JRequest::getVar('Itemid');
$menu   = $app->getMenu();
$active = $menu->getActive($itemid);
$params = $menu->getParams( $active->id );
$pageclass = $params->get( 'pageclass_sfx' );
$pagehead = $params->get('page_heading');
$this->setTitle( $this->getTitle());
$doc = JFactory::getDocument();
$user = JFactory::getUser();
$this->language  = $doc->language;
$lang = JFactory::getLanguage();
$pagetitle=$doc->getTitle();
$_SESSION['language']=$this->language;

require("php/variables.php");

// Remove Scripts
unset($doc->_scripts[JURI::root(true) . '/media/jui/js/bootstrap.min.js']);
?>

<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="<?php echo $this->language; ?>" class="no-js">
<!-- head -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<jdoc:include type="head" />
<!--css-->
<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/sematic-assets.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/style.css">
<?php if ($menu->getActive() == $menu->getDefault()) {?>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/home.css" rel="stylesheet" type="text/css" />
<?php }
?>
<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/custom.css" rel="stylesheet" type="text/css" />
<!--endcss-->
</head>
<!-- /head -->

<!-- =========================================
    body
    ========================================== -->
<body>

<!-- Container -->
<div id="container"> 
  <!-- Header
		    ================================================== -->
  <header class="clearfix">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container"> 
      <?php if($this->params->get('logo')==NULL) { ?> 
      <a class="navbar-brand" href="index.php"><img src="templates/sematic/images/logo.png" alt=""> </a>
      <?php } else { ?>
      <a class="navbar-brand" href="index.php"><img src="<?php echo $logo; ?>" alt=""></a>
      <?php } ?>
          
      <?php if($this->countModules('js-menu')) { ?>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <jdoc:include type="modules" name="js-menu" style="nomoduletablediv" />
          </ul>
        </div>
       <?php } ?>
      </div>
    </nav>
  </header>
  <!-- End Header --> 
  
  <?php if($this->countModules('js-slideshow2')) { ?>
  <!-- home-section 
			================================================== -->
  <section id="home-section" class="background-color-style">
    <div class="slider-text">
      <div class="flexslider">
        <jdoc:include type="modules" name="js-slideshow2" style="nomoduletablediv" />
      </div>
    </div>
  </section>
  <!-- End home section --> 
  <?php } ?>
  
  <?php if ($menu->getActive() != $menu->getDefault($lang->getTag())) { ?>
  <!-- banner-page-section 
			================================================== -->
  <section class="page-banner-section">
      <div class="container">
          <h1><?php echo $pagetitle; ?></h1>
      </div>
  </section>

  <!-- End banner-page-section -->
  <?php } ?>
  
  <!-- content Section -->
  <?php
	if(($this->countModules('js-left')) || ($this->countModules('js-right')))
    { ?>
  <section class="blog-section single-post">
    <div class="container">
      <div class="row">
        <?php if($this->countModules('js-left')) { ?>
        <div class="col-md-4">
          <div class="sidebar">
            <jdoc:include type="modules" name="js-left" style="leftright" />
          </div>
        </div>
        <?php } ?>
        <div class="col-md-8">
          <jdoc:include type="message" />
          <jdoc:include type="component" />
        </div>
        <?php if($this->countModules('js-right')) { ?>
        <div class="col-md-4">
          <div class="sidebar">
            <jdoc:include type="modules" name="js-right" style="leftright" />
          </div>
        </div>
        <?php } ?>
      </div>
    </div>
  </section>
  <?php } else { ?>
  <jdoc:include type="message" />
  <jdoc:include type="component" />
  <?php } ?>
  <!-- Content Section -->
  
  
  <?php if($this->countModules('js-about')) { ?>
  <!-- about-section 
			================================================== -->
  <section id="about-section">
    <div class="container">
      <jdoc:include type="modules" name="js-about" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End about section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-statistic')) { ?>
  <!-- statistic-section 
			================================================== -->
  <section class="statistic-section">
    <div class="container">
      <jdoc:include type="modules" name="js-statistic" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End statistic section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-team')) { ?>
  <!-- team-section 
			================================================== -->
  <section id="team-section">
    <div class="container">
      <jdoc:include type="modules" name="js-team" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End team section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-portfolio')) { ?>
  <!-- portfolio-section 
			================================================== -->
      <jdoc:include type="modules" name="js-portfolio" style="nomoduletablediv" />
  <!-- End portfolio section --> 
  <?php } ?>
  
  
  <?php if($this->countModules('js-banner')) { ?>
  <!-- banner-section 
			================================================== -->
  <section class="banner-section">
    <div class="container">
      <jdoc:include type="modules" name="js-banner" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End banner section --> 
  <?php } ?>
  
  
  <?php if($this->countModules('js-services')) { ?>
  <!-- services-section 
			================================================== -->
  <section id="services-section">
    <div class="container">
      <jdoc:include type="modules" name="js-services" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End services section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-blog')) { ?>
  <!-- blog-section 
			================================================== -->
  <section id="blog-section">
    <div class="container">
      <jdoc:include type="modules" name="js-blog" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End blog section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-tweets')) { ?>
  <!-- tweets-section 
			================================================== -->
  <section class="tweets-section">
    <div class="container">
      <div class="tweets-box">
        <p><i class="fa fa-twitter"></i></p>
        <jdoc:include type="modules" name="js-tweets" style="nomoduletablediv" />
      </div>
    </div>
  </section>
  <!-- End tweets section --> 
  
  <?php } ?>
  
  <?php if($this->countModules('js-testimonial')) { ?>
  <!-- testimonial-section 
			================================================== -->
  <section id="testimonial-section">
    <div class="container">
      <jdoc:include type="modules" name="js-testimonial" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End testimonial section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-clients')) { ?>
  <!-- clients-section 
			================================================== -->
  <section id="clients-section">
    <div class="container">
      <jdoc:include type="modules" name="js-clients" style="nomoduletablediv" />
    </div>
  </section>
  <!-- End clients section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-contact') || $this->countModules('js-map')) { ?>
  <!-- contact-section 
			================================================== -->
  <section id="contact-section">
    <jdoc:include type="modules" name="js-map" style="nomoduletablediv" />
    
    
    <div class="contact-info-box">
      <div class="container">
        <div class="title-section">
          <h1>Our Contact Info</h1>
          <span></span>
          <p>Our team created best opportunities for your business.</p>
        </div>
        <div class="contact-box">
          <div class="row">
            <jdoc:include type="modules" name="js-contact" style="nomoduletable" />
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End contact section --> 
  <?php } ?>
  
  <?php if($this->countModules('js-footer')) { ?>
  <!-- footer 
			================================================== -->
  <footer>
    <div class="container">
      <div class="row">
        <jdoc:include type="modules" name="js-footer" style="nomoduletablediv" />
      </div>
    </div>
  </footer>
  <!-- End footer --> 
  <?php } ?>
</div>
<!-- End Container -->

<div class="preloader"> <img alt="" src="templates/sematic/images/loader.gif"> </div>
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/sematic-plugins.min.js"></script> 
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/popper.js"></script> 
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/bootstrap.min.js"></script> 
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/jquery.countTo.js"></script> 
<script src="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/js/script.js"></script>
</body>
<!-- /body -->
</html>
<!-- /html -->