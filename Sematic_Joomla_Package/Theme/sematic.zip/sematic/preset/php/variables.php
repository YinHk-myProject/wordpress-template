<?php
/*
* @package Sematic
* @copyright (C) 2018 by Joomlastars - All rights reserved!
* @license GNU General Public License, version 2 (http://www.gnu.org/licenses/gpl-2.0.html)
* @author Joomlastars <author@joomlastars.co.in>
* @authorurl <http://themeforest.net/user/joomlastars>
*/
?>
<?php
defined( '_JEXEC' ) or die( 'Restricted index access' );
$path = $this->baseurl.'/templates/'.$this->template;
$app = JFactory::getApplication();

//factory
$document = JFactory::getDocument();

//General
$app->getCfg('sitename');
$siteName = $this->params->get('siteName');
$templateparams	= $app->getTemplate(true)->params;

//Logo Options
$logo = $this->params->get('logo');
 
 
//Home Versions
$homepage_layout = $this->params->get('homepage_layout');


?>