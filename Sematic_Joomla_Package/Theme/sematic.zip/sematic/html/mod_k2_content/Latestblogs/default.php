<?php
/**
 * @version    2.9.x
 * @package    K2
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2006 - 2018 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 */

// no direct access
defined('_JEXEC') or die;
?>
<?php if($params->get('itemPreText')): ?>

<p class="modulePretext"><?php echo $params->get('itemPreText'); ?></p>
<?php endif; ?>
<?php if(count($items)): ?>
<div class="blog-box">
<div class="owl-wrapper">
<div class="owl-carousel" data-num="3">
<?php foreach ($items as $key=>$item):	?>
<div class="item">
  <div class="blog-post">
    <div class="post-image">
      <?php if($params->get('itemImage') && isset($item->image)): ?>
      <a href="<?php echo $item->link; ?>" title="<?php echo JText::_('K2_CONTINUE_READING'); ?> &quot;<?php echo K2HelperUtilities::cleanHtml($item->title); ?>&quot;"> <img src="<?php echo $item->image; ?>" alt="<?php echo K2HelperUtilities::cleanHtml($item->title); ?>" /> </a>
      <?php endif; ?>
    </div>
    <div class="post-content">
      <?php if($params->get('itemTitle')): ?>
      <h2><a href="<?php echo $item->link; ?>"><?php echo $item->title; ?></a></h2>
      <?php endif; ?>
      <ul class="post-tags">
        <li><i class="fa fa-clock-o"></i><span><?php echo JHTML::_('date', $item->created, JText::_('K2_DATE_FORMAT_LC2')); ?></span></li>
        <li><i class="fa fa-comments-o"></i><span>
          <?php if($params->get('itemCommentsCounter') && $componentParams->get('comments')): ?>
          <?php if(!empty($item->event->K2CommentsCounter)): ?>
          <!-- K2 Plugins: K2CommentsCounter --> 
          <?php echo $item->event->K2CommentsCounter; ?>
          <?php else: ?>
          <?php if($item->numOfComments>0): ?>
          <a class="moduleItemComments" href="<?php echo $item->link.'#itemCommentsAnchor'; ?>"> <?php echo $item->numOfComments; ?>
          <?php if($item->numOfComments>1) echo JText::_('K2_COMMENTS'); else echo JText::_('K2_COMMENT'); ?>
          </a>
          <?php else: ?>
          <a class="moduleItemComments" href="<?php echo $item->link.'#itemCommentsAnchor'; ?>"> <?php echo JText::_('K2_BE_THE_FIRST_TO_COMMENT'); ?> </a>
          <?php endif; ?>
          <?php endif; ?>
          <?php endif; ?>
          </span> </li>
      </ul>
      <?php if($params->get('itemIntroText')): ?>
      <?php echo $item->introtext; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
