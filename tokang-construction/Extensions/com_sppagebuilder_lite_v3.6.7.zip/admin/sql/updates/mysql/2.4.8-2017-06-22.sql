ALTER TABLE `#__sppagebuilder` ADD `asset_id` int(11) NOT NULL AFTER `id`;
